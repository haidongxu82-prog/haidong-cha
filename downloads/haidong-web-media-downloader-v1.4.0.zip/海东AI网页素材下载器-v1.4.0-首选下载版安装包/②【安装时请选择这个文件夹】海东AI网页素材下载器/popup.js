// ================== 页面内执行的扫描函数 ==================
// 这个函数会被注入当前页面：电商页扫描详情素材，普通页只扫描当前可见的主体媒体。
// 必须是自包含的（不能引用外部变量），因为它会被序列化后发到页面上下文执行。
async function scanPageMedia() {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  const commerceHost = /(^|\.)(taobao|tmall|1688|alibaba|jd|yangkeduo|pinduoduo|douyin|jinritemai)\.com$/i.test(location.hostname);
  const originalY = window.scrollY;
  if (commerceHost) {
    const totalHeight = Math.min(
      Math.max(document.body.scrollHeight, document.documentElement.scrollHeight),
      30000
    );
    const step = Math.max(window.innerHeight, 700);
    for (let y = 0; y < totalHeight; y += step) {
      window.scrollTo(0, y);
      await sleep(100);
    }
    window.scrollTo(0, originalY);
    await sleep(180);
  }

  const results = new Map(); // key: 归一化 url -> {url, type, ext, w, h}

  const isVisible = (el, requireViewport = !commerceHost) => {
    if (!el || !el.isConnected) return false;
    const style = getComputedStyle(el);
    if (
      style.display === "none" ||
      style.visibility === "hidden" ||
      Number.parseFloat(style.opacity || "1") < 0.05
    ) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width < 180 || rect.height < 120) return false;
    if (!requireViewport) return true;
    const margin = Math.round(window.innerHeight * 0.25);
    return (
      rect.bottom >= -margin &&
      rect.top <= window.innerHeight + margin &&
      rect.right >= 0 &&
      rect.left <= window.innerWidth
    );
  };

  const inExcludedArea = (el) => {
    const bad = /(recommend|suggest|history|recent|advert|banner|carousel|template|gallery|sidebar|footer)/i;
    let node = el;
    for (let i = 0; node && i < 6; i += 1, node = node.parentElement) {
      const mark = `${node.id || ""} ${typeof node.className === "string" ? node.className : ""} ${node.getAttribute?.("aria-label") || ""}`;
      if (bad.test(mark)) return true;
    }
    return false;
  };

  const toAbs = (u) => {
    if (!u) return null;
    u = u.trim();
    if (!u || u.startsWith("data:") || u.startsWith("blob:")) return null;
    if (u.startsWith("//")) u = "https:" + u;
    try {
      return new URL(u, location.href).href;
    } catch (e) {
      return null;
    }
  };

  // 淘宝/1688 缩略图升级为原图：去掉 xxx.jpg_460x460q90.jpg_.webp 这类尺寸后缀
  const upgrade = (u) =>
    u.replace(/(\.(?:jpg|jpeg|png))_[^/?#]*$/i, "$1");

  const imgExt = (u) => {
    const m = u.match(/\.(jpg|jpeg|png|webp|gif|bmp)(?:[?#]|$)/i);
    return m ? m[1].toLowerCase().replace("jpeg", "jpg") : "jpg";
  };
  const vidExt = (u) => {
    const m = u.match(/\.(mp4|webm|mov|m4v|m3u8)(?:[?#]|$)/i);
    return m ? m[1].toLowerCase() : "mp4";
  };

  const addImage = (raw, w, h) => {
    let abs = toAbs(raw);
    if (!abs) return;
    abs = upgrade(abs);
    // 过滤明显的小图标（已知自然尺寸且很小的）
    if (w && h && w < 200 && h < 200) return;
    const key = abs.split(/[?#]/)[0];
    const prev = results.get(key);
    const area = (w || 0) * (h || 0);
    if (!prev || (prev.type === "image" && area > (prev.area || 0))) {
      results.set(key, { url: abs, type: "image", ext: imgExt(abs), w, h, area });
    }
  };

  const addVideo = (raw) => {
    const abs = toAbs(raw);
    if (!abs) return;
    const key = abs.split(/[?#]/)[0];
    results.set(key, { url: abs, type: "video", ext: vidExt(abs) });
  };

  // 2) 收集 <img>
  const lazyAttrs = [
    "data-src",
    "data-original",
    "data-lazy-src",
    "data-ks-lazyload",
    "data-image",
    "data-lazy",
    "data-echo",
  ];
  document.querySelectorAll("img").forEach((img) => {
    if (!isVisible(img) || (!commerceHost && inExcludedArea(img))) return;
    const w = img.naturalWidth || img.width || 0;
    const h = img.naturalHeight || img.height || 0;
    if (img.currentSrc) addImage(img.currentSrc, w, h);
    if (img.src) addImage(img.src, w, h);
    // srcset 取最大
    if (img.srcset) {
      let best = null,
        bestW = -1;
      img.srcset.split(",").forEach((part) => {
        const seg = part.trim().split(/\s+/);
        const url = seg[0];
        const d = parseInt((seg[1] || "").replace(/\D/g, "")) || 0;
        if (d >= bestW) {
          bestW = d;
          best = url;
        }
      });
      if (best) addImage(best, w, h);
    }
    lazyAttrs.forEach((a) => {
      const v = img.getAttribute(a);
      if (v) addImage(v, w, h);
    });
  });

  // 3) 收集较大元素的背景图（部分主图用 background-image）
  document.querySelectorAll("*").forEach((el) => {
    if (!isVisible(el) || (!commerceHost && inExcludedArea(el))) return;
    const rect = el.getBoundingClientRect
      ? el.getBoundingClientRect()
      : { width: 0, height: 0 };
    if (rect.width < 200 || rect.height < 200) return;
    const bg = getComputedStyle(el).backgroundImage;
    if (bg && bg !== "none") {
      const m = bg.match(/url\(["']?(.*?)["']?\)/i);
      if (m && m[1]) addImage(m[1], Math.round(rect.width), Math.round(rect.height));
    }
  });

  // 4) 收集 <video>
  const videos = Array.from(document.querySelectorAll("video"));
  let visibleVideos = videos.filter((v) => isVisible(v, true) && !inExcludedArea(v));
  if (!visibleVideos.length && videos.length) {
    visibleVideos = videos
      .filter((v) => isVisible(v, false) && !inExcludedArea(v))
      .sort((a, b) => {
        const ar = a.getBoundingClientRect();
        const br = b.getBoundingClientRect();
        return br.width * br.height - ar.width * ar.height;
      })
      .slice(0, 1);
  }
  visibleVideos.forEach((v) => {
    // 同一播放器只保留一个最优地址，避免 src/currentSrc/source 重复计数。
    const best = v.currentSrc || v.src || v.querySelector("source[src]")?.src;
    if (best) addVideo(best);
  });

  // 页面标题（用于命名文件夹）
  const title =
    document.querySelector('meta[property="og:title"]')?.content ||
    document.title ||
    location.hostname;

  const items = Array.from(results.values()).slice(0, 300);
  return { items, title };
}

// ================== 弹窗控制逻辑 ==================
let scanned = [];

const $ = (id) => document.getElementById(id);
const statusEl = $("status");

function setStatus(text) {
  statusEl.textContent = text;
}

function enableButtons(images, videos) {
  $("btnAll").disabled = images + videos === 0;
  $("btnImg").disabled = images === 0;
  $("btnVideo").disabled = videos === 0;
  $("btnSelectAll").disabled = images + videos === 0;
}

function formatDimensions(item) {
  if (item.w && item.h) return `${item.w}×${item.h}`;
  return "尺寸未知";
}

function updateSelectionUI() {
  const choices = Array.from(document.querySelectorAll(".media-choice"));
  const selected = choices.filter((choice) => choice.checked).length;
  $("selectedCount").textContent = `已选 ${selected} 项`;
  $("btnPreferred").disabled = selected === 0;
  $("btnClearSelection").disabled = selected === 0;
}

function renderSelection() {
  const list = $("selectionList");
  list.innerHTML = "";

  if (scanned.length === 0) {
    const empty = document.createElement("div");
    empty.className = "selection-empty";
    empty.textContent = "扫描到素材后，可在这里勾选首选下载项。";
    list.appendChild(empty);
    updateSelectionUI();
    return;
  }

  scanned.forEach((item, index) => {
    const row = document.createElement("label");
    row.className = "selection-item";
    row.title = item.url;

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.className = "media-choice";
    checkbox.dataset.index = String(index);
    checkbox.setAttribute("aria-label", `选择${item.type === "video" ? "视频" : "图片"} ${index + 1}`);
    row.appendChild(checkbox);

    const thumb = document.createElement("div");
    thumb.className = "selection-thumb";
    if (item.type === "video") {
      thumb.classList.add("video-thumb");
      thumb.textContent = "▶ 视频";
    } else {
      const img = document.createElement("img");
      img.src = item.url;
      img.alt = `图片 ${index + 1}`;
      img.loading = "lazy";
      img.decoding = "async";
      thumb.appendChild(img);
    }
    row.appendChild(thumb);

    const meta = document.createElement("div");
    meta.className = "selection-meta";
    const title = document.createElement("div");
    title.className = "selection-title";
    title.textContent = `${item.type === "video" ? "视频" : "图片"} ${String(index + 1).padStart(3, "0")} · ${formatDimensions(item)} · .${item.ext || "未知"}`;
    const source = document.createElement("div");
    source.className = "selection-source";
    source.textContent = item.url;
    meta.appendChild(title);
    meta.appendChild(source);
    row.appendChild(meta);

    list.appendChild(row);
  });

  updateSelectionUI();
}

function render(data) {
  scanned = data.items || [];
  const images = scanned.filter((i) => i.type === "image");
  const videos = scanned.filter((i) => i.type === "video");

  $("imgCount").textContent = images.length;
  $("videoCount").textContent = videos.length;

  if (!$("folderName").value.trim()) {
    $("folderName").value = (data.title || "商品").trim();
  }

  // 缩略图预览（最多 24 个）
  const preview = $("preview");
  preview.innerHTML = "";
  scanned.slice(0, 24).forEach((item) => {
    const div = document.createElement("div");
    div.className = "thumb";
    if (item.type === "video") {
      div.innerHTML = `<span class="badge">视频</span>`;
      div.style.display = "flex";
      div.style.alignItems = "center";
      div.style.justifyContent = "center";
      div.style.fontSize = "11px";
      div.appendChild(document.createTextNode("▶"));
    } else {
      const img = document.createElement("img");
      img.src = item.url;
      img.loading = "lazy";
      div.appendChild(img);
    }
    preview.appendChild(div);
  });

  enableButtons(images.length, videos.length);
  renderSelection();
  setStatus(`共找到 图片 ${images.length} 张、视频 ${videos.length} 个。`);
}

function renderSelfCheck() {
  const box = $("selfcheck");
  // 再点一次收起
  if (!box.hidden) {
    box.hidden = true;
    return;
  }
  box.innerHTML = "";

  const groups = [
    ["图片", scanned.filter((i) => i.type === "image")],
    ["视频", scanned.filter((i) => i.type === "video")],
  ];

  const LIMIT = 8; // 每类最多列 8 条，够核对了
  groups.forEach(([name, list]) => {
    const title = document.createElement("div");
    title.className = "sc-group";
    title.textContent = `${name}（${list.length}）`;
    box.appendChild(title);

    if (list.length === 0) {
      const empty = document.createElement("div");
      empty.className = "sc-empty";
      empty.textContent = "—— 没抓到 ——";
      box.appendChild(empty);
      return;
    }

    list.slice(0, LIMIT).forEach((item, i) => {
      const row = document.createElement("div");
      row.className = "sc-row";
      const idx = document.createElement("span");
      idx.className = "sc-idx";
      idx.textContent = `${String(i + 1).padStart(2, "0")}.${item.ext}`;
      const a = document.createElement("a");
      a.className = "sc-url";
      a.href = item.url;
      a.target = "_blank";
      a.rel = "noopener";
      a.textContent = item.url;
      a.title = "点击在新标签页打开，核对是不是这个商品的";
      row.appendChild(idx);
      row.appendChild(a);
      box.appendChild(row);
    });

    if (list.length > LIMIT) {
      const more = document.createElement("div");
      more.className = "sc-empty";
      more.textContent = `…… 还有 ${list.length - LIMIT} 条未列出`;
      box.appendChild(more);
    }
  });

  box.hidden = false;
}

async function runScan() {
  setStatus("正在扫描当前页面…");
  $("selfcheck").hidden = true;
  $("btnAll").disabled = $("btnImg").disabled = $("btnVideo").disabled = true;
  $("btnPreferred").disabled = $("btnSelectAll").disabled = $("btnClearSelection").disabled = true;

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/^https?:/.test(tab.url || "")) {
    setStatus("请在电商商品网页上使用（当前页面无法扫描）。");
    return;
  }

  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: scanPageMedia,
    });
    render(result || { items: [], title: tab.title });
  } catch (e) {
    setStatus("扫描失败：" + (e.message || e));
  }
}

function download(kind) {
  const folder = $("folderName").value.trim() || "商品";
  let list = scanned;
  if (kind === "image") list = scanned.filter((i) => i.type === "image");
  if (kind === "video") list = scanned.filter((i) => i.type === "video");
  if (kind === "preferred") {
    const indexes = Array.from(document.querySelectorAll(".media-choice:checked"), (choice) => Number(choice.dataset.index));
    list = indexes.map((index) => scanned[index]).filter(Boolean);
  }

  // 按类别各自从 1 开始编号
  const counters = { 图片: 0, 视频: 0 };
  const items = list.map((i) => {
    const category = i.type === "video" ? "视频" : "图片";
    counters[category] += 1;
    return { url: i.url, category, ext: i.ext, index: counters[category] };
  });

  if (items.length === 0) return;
  setStatus(kind === "preferred" ? `开始下载手选的 ${items.length} 个文件…` : `开始下载 ${items.length} 个文件…`);

  chrome.runtime.sendMessage(
    { type: "DOWNLOAD_ITEMS", folder, items },
    (resp) => {
      if (chrome.runtime.lastError) {
        setStatus("下载出错：" + chrome.runtime.lastError.message);
        return;
      }
      if (resp && resp.ok) {
        if (resp.failed && resp.started === 0) {
          const reason = resp.errors && resp.errors.length ? `（原因：${resp.errors[0]}）` : "";
          setStatus(`全部 ${resp.failed} 个下载失败${reason}。若是防盗链，请「重新扫描」后重试；仍失败请把此提示发给海东。`);
        } else {
          const failMsg = resp.failed ? `，失败 ${resp.failed} 个` : "";
          setStatus(`已开始下载 ${resp.started} 个文件${failMsg}。存到「下载/电商素材/${folder}/」`);
        }
      } else {
        setStatus("下载未能开始，请重试。");
      }
    }
  );
}

document.addEventListener("DOMContentLoaded", () => {
  $("btnAll").addEventListener("click", () => download("all"));
  $("btnImg").addEventListener("click", () => download("image"));
  $("btnVideo").addEventListener("click", () => download("video"));
  $("btnPreferred").addEventListener("click", () => download("preferred"));
  $("btnSelectAll").addEventListener("click", () => {
    document.querySelectorAll(".media-choice").forEach((choice) => {
      choice.checked = true;
    });
    updateSelectionUI();
  });
  $("btnClearSelection").addEventListener("click", () => {
    document.querySelectorAll(".media-choice").forEach((choice) => {
      choice.checked = false;
    });
    updateSelectionUI();
  });
  $("selectionList").addEventListener("change", updateSelectionUI);
  $("btnRescan").addEventListener("click", runScan);
  $("btnSelfCheck").addEventListener("click", renderSelfCheck);
  runScan();
});
