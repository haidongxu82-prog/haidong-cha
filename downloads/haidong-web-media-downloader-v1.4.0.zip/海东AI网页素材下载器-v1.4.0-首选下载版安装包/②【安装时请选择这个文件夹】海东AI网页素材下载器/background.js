// Service worker：负责把弹窗里选好的素材下载到「下载文件夹 / 电商素材 / 商品名 / 图片(或视频)」中。
// Chrome 插件出于安全限制，只能下载到系统下载目录下的子文件夹，无法直接写任意盘符路径。

// ============ 防盗链处理 ============
// 天猫/淘宝/拼多多/抖音等平台的图片、视频 CDN 会校验 Referer（来路），
// 直接下载会被 403 拒绝。这里用 declarativeNetRequest 给对应 CDN 的请求
// 改写 Referer，伪装成从各自平台页面正常访问，绕过防盗链。
const REFERER_RULES = [
  {
    id: 1001,
    domains: [
      "alicdn.com",
      "taobao.com",
      "tmall.com",
      "alibaba.com",
      "1688.com",
      "mmcdn.cn",
      "aliyuncs.com",
    ],
    referer: "https://www.taobao.com/",
  },
  {
    id: 1002,
    domains: ["pinduoduo.com", "yangkeduo.com", "pddpic.com", "pinimg.com"],
    referer: "https://mobile.yangkeduo.com/",
  },
  {
    id: 1003,
    domains: [
      "douyinpic.com",
      "douyinvod.com",
      "byteimg.com",
      "bytecdn.cn",
      "ixigua.com",
      "douyin.com",
      "zjcdn.com",
      "ibyteimg.com",
    ],
    referer: "https://www.douyin.com/",
  },
];

async function setupRefererRules() {
  try {
    const addRules = REFERER_RULES.map((r) => ({
      id: r.id,
      priority: 1,
      action: {
        type: "modifyHeaders",
        requestHeaders: [
          { header: "referer", operation: "set", value: r.referer },
          { header: "origin", operation: "remove" },
        ],
      },
      condition: {
        requestDomains: r.domains,
        resourceTypes: [
          "image",
          "media",
          "other",
          "xmlhttprequest",
          "sub_frame",
          "main_frame",
        ],
      },
    }));
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: REFERER_RULES.map((r) => r.id),
      addRules,
    });
  } catch (e) {
    console.warn("设置防盗链规则失败：", e);
  }
}

chrome.runtime.onInstalled.addListener(setupRefererRules);
chrome.runtime.onStartup.addListener(setupRefererRules);
setupRefererRules();

// ============ 下载分类 ============
// 去掉 Windows/Mac 文件名里的非法字符，并做长度截断，避免路径过长。
function sanitize(name, max = 40) {
  const cleaned = (name || "")
    .replace(/[\\/:*?"<>|\r\n\t]/g, " ") // 非法字符换空格
    .replace(/[.\s]+$/g, "") // 去掉结尾的点和空格（部分系统不允许）
    .replace(/\s+/g, " ")
    .trim();
  return (cleaned || "未命名").slice(0, max).replace(/[.\s]+$/g, "").trim() || "未命名";
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "DOWNLOAD_ITEMS") {
    const folder = sanitize(msg.folder);
    const items = Array.isArray(msg.items) ? msg.items : [];

    let started = 0;
    let failed = 0;
    let pending = items.length;
    const errors = [];

    if (pending === 0) {
      sendResponse({ ok: true, started: 0, failed: 0, errors });
      return true;
    }

    items.forEach((item) => {
      // item = { url, category: '图片'|'视频', ext, index }
      const sub = item.category === "视频" ? "视频" : "图片";
      const seq = String(item.index).padStart(3, "0");
      const ext = item.ext || (sub === "视频" ? "mp4" : "jpg");
      const filename = `电商素材/${folder}/${sub}/${seq}.${ext}`;

      chrome.downloads.download(
        {
          url: item.url,
          filename,
          conflictAction: "uniquify", // 同名自动加序号，不覆盖
          saveAs: false,
        },
        (downloadId) => {
          if (chrome.runtime.lastError || downloadId === undefined) {
            failed++;
            const m = chrome.runtime.lastError && chrome.runtime.lastError.message;
            if (m && errors.length < 3 && !errors.includes(m)) errors.push(m);
          } else {
            started++;
          }
          pending--;
          if (pending === 0) {
            sendResponse({ ok: true, started, failed, errors });
          }
        }
      );
    });

    return true; // 保持消息通道打开，等待异步 sendResponse
  }
});
